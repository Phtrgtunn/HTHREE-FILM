-- Add profile columns to users table
ALTER TABLE `users` 
ADD COLUMN IF NOT EXISTS `phone` VARCHAR(20) NULL AFTER `email`,
ADD COLUMN IF NOT EXISTS `bio` TEXT NULL AFTER `phone`,
ADD COLUMN IF NOT EXISTS `avatar` VARCHAR(255) NULL AFTER `bio`;

-- Add updated_at if not exists
ALTER TABLE `users` 
ADD COLUMN IF NOT EXISTS `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`;
